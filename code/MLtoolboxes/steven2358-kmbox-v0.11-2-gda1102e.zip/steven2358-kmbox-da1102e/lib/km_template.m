function y = km_template(x)
% KM_TEMPLATE defines the structure of a default function in the Kernel
% Methods Toolbox. Modify this file to write custom functions.
%
% Author: authorname (authoremail), year.
% 
% This file is part of the Kernel Methods Toolbox for MATLAB.
% https://github.com/steven2358/kmbox

y = x;
