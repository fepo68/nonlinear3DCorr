% KM_DEMO_TEMPLATE defines the structure of a demo file in the Kernel
% Methods Toolbox.
%
% The extended description of the demo goes here.
%
% Author: authorname (authoremail), year.
%
% This file is part of the Kernel Methods Toolbox for MATLAB.
% https://github.com/steven2358/kmbox

close all
clear

%% PARAMETERS

%% PROGRAM
tic

toc
%% OUTPUT
