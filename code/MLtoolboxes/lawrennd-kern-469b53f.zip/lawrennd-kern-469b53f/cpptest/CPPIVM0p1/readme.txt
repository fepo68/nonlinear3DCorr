ReadMe file for the CPPIVM toolbox version 0.1 Sunday, May 1, 2005 at 15:41:10
Written by Guido Sanguinetti and Neil D. Lawrence.

License Info
------------

This software is free for academic use. Please contact Neil Lawrence if you are interested in using the software for commercial purposes.

This software must not be distributed or modified without prior permission of the author.



File Listing
------------

