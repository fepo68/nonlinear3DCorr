function gX = invcmpndKernGradX(kern, X, X2)

% INVCMPNDKERNGRADX 
% See: cmpndKernGradX...
% SEEALSO cmpndKernParamInit, kernGradX, cmpndKernDiagGradX
%

% KERN

error('invcmpndKernGradX not yet implemented!')
